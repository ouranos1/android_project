package com.example.travel_project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class signupActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        Button btnSignup = findViewById(R.id.signupconfirm);
        //btnLogin.setOnClickListener(this);
        EditText EditTextID = (EditText)findViewById(R.id.signupID);
        EditText EditTextPS = (EditText)findViewById(R.id.signupPS);
        EditText EditTextPScheck = (EditText)findViewById(R.id.signupPScheck);
        EditText EditTextNickname = (EditText)findViewById(R.id.signupNickname);
        EditText EditTextEmail = (EditText)findViewById(R.id.signupEmail);

        btnSignup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // 아이디 빈칸일 때
                if ( EditTextID.getText().toString().length() == 0 ) {
                    Toast.makeText(getApplicationContext(), "아이디를 입력하세요.",Toast.LENGTH_LONG).show();
                    //비밀번호 빈칸일 때
                } else if ( EditTextPS.getText().toString().length() == 0) {
                    Toast.makeText(getApplicationContext(), "비밀번호를 입력하세요.",Toast.LENGTH_LONG).show();
                    //비밀번호 확인 빈칸일 때
                } else if ( EditTextPScheck.getText().toString().length() == 0 ) {
                    Toast.makeText(getApplicationContext(), "비밀번호 확인을 입력하세요.",Toast.LENGTH_LONG).show();
                    //닉네임 빈칸일 때
                } else if ( EditTextNickname.getText().toString().length() == 0 ) {
                    Toast.makeText(getApplicationContext(), "닉네임을 입력하세요.",Toast.LENGTH_LONG).show();
                    //이메일 빈칸일 때
                } else if ( EditTextEmail.getText().toString().length() == 0 ) {
                    Toast.makeText(getApplicationContext(), "이메일을 입력하세요.",Toast.LENGTH_LONG).show();
                    // 모든 항목이 채워졌을 때
                } else {
                    String ID =  EditTextID.getText().toString();
                    String PS =  EditTextPS.getText().toString();
                    String PScheck =  EditTextPScheck.getText().toString();
                    String Nickname =  EditTextNickname.getText().toString();
                    String Email =  EditTextEmail.getText().toString();

                    //영어, 숫자만 입력되도록
                    Pattern ps = Pattern.compile("^[a-zA-Z0-9]+$");

                    if ( PScheck.length() < 8) {
                        Toast.makeText(getApplicationContext(), "비밀번호는 8자리 이상이어야 합니다.", Toast.LENGTH_LONG).show();
                    } else if ( ps.matcher(PScheck).matches()) {
                        // 특수문자 입력해도 회원가입 됨; 영어+숫자 입력하면 회원가입 안됨; 특수문자 꼭 포함되어야 회원가입 됨; 한글을 입력할 수 없어서 테스트 불가;
                        Toast.makeText(getApplicationContext(), "한글, 특수문자는 비밀번호에 포함할 수 없습니다.",Toast.LENGTH_LONG).show();
                    } else if (EditTextPS.getText().toString().equals(EditTextPScheck.getText().toString())) {
                        Toast.makeText(getApplicationContext(), Nickname + "님 회원가입을 축하드립니다 ><",Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(v.getContext(),loginActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(getApplicationContext(), "비밀번호가 일치하지 않습니다.",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
    public void clickcancel(View view) {
        Intent intent = new Intent(this,loginActivity.class);
        startActivity(intent);
    }
}