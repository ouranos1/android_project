package com.example.travel_project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

public class loginActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        Button btnLogin = findViewById(R.id.login);
        //btnLogin.setOnClickListener(this);
        EditText EditTextID = (EditText)findViewById(R.id.EditTextID);
        EditText EditTextPS = (EditText)findViewById(R.id.EditTextPS);

        btnLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // 아이디와 패스워드 둘 다 빈칸일 때
                if ( EditTextID.getText().toString().length() == 0 && EditTextPS.getText().toString().length() == 0) {
                    Toast.makeText(getApplicationContext(), "아이디와 비밀번호를 입력하세요.",Toast.LENGTH_LONG).show();
                    //아이디 빈칸일 때
                } else if ( EditTextID.getText().toString().length() == 0) {
                    Toast.makeText(getApplicationContext(), "아이디를 입력하세요.",Toast.LENGTH_LONG).show();
                    //패스워드 빈칸일 때
                } else if ( EditTextPS.getText().toString().length() == 0 ) {
                    Toast.makeText(getApplicationContext(), "비밀번호를 입력하세요.",Toast.LENGTH_LONG).show();
                } else {
                    //입력칸이 모두 공백이 아닐 때
                    String ID =  EditTextID.getText().toString();
                    String PS =  EditTextPS.getText().toString();
                    Toast.makeText(getApplicationContext(), "id는 "+ID+"이며, 비밀번호는 "+PS+"입니다.",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(v.getContext(),MainActivity.class);
                    startActivity(intent);

                }
            }
        });
    }
    public void clicksignup(View view) {
        Intent intent = new Intent(this,signupActivity.class);
        startActivity(intent);
    }
}