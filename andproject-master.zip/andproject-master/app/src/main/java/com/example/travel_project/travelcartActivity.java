package com.example.travel_project;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import com.google.android.material.navigation.NavigationView;

import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.Calendar;


public class travelcartActivity extends Activity {

    TextView textView;

    String[] items1 = {"관광지1", "관광지2", "관광지3", "관광지4"};
    String[] items2 = {"11월 19일", "11월 20일", "11월 21일", "11월 22일"};

    private int myYear, myMonth, myDay, myHour, myMinute;

    Button btnClick;
    Button btnOK;
    Button btnClose;
    Button travelstartdate;
    Button travelenddate;
    Button travelstarttime;
    Button travelendtime;

    private static final String TAG = "travelcartActivity";

    private Context mContext = travelcartActivity.this;
    private NavigationView nav;

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "onNewIntent: 호출");
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.travelcart);

        init();
        NavigationViewHelper.enableNavigation(mContext,nav);


        final DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);

        findViewById(R.id.imageMenu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // start에 지정된 Drawer 열기
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        NavigationView navigationView = findViewById(R.id.navigationView);
        navigationView.setItemIconTintList(null);



        //bottomsheet 구현 https://jwsoft91.tistory.com/45 I love tistory.
        btnClick = findViewById(R.id.travelplanadd);

        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.bottomsheet_travelcart, null, false);
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(view);




        //spinner 구현 (교재 444p) ==================================================
        Spinner spinner1 = view.findViewById(R.id.schedulename);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(
                //API에 만들어져 있는 R.layout.simple_spinner...를 씀
                this,android.R.layout.simple_spinner_item, items1
        );
        //미리 정의된 레이아웃 사용
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        // 스피너 객체에다가 어댑터를 넣어줌
        spinner1.setAdapter(adapter1);
        //spinner 구현 =============================================================






        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.show();
            }
        });

        btnOK = view.findViewById(R.id.btnOK);
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "추가", Toast.LENGTH_SHORT).show();
                bottomSheetDialog.dismiss();
            }
        });

        btnClose = view.findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "취소", Toast.LENGTH_SHORT).show();
                bottomSheetDialog.dismiss();
            }
        });



        //datepicker
        final Calendar c = Calendar.getInstance();

        travelstartdate = view.findViewById(R.id.travelstartdate);
        travelstartdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myYear = c.get(Calendar.YEAR);
                myMonth = c.get(Calendar.MONTH);
                myDay = c.get(Calendar.DAY_OF_MONTH);

                Dialog dlgDate = new DatePickerDialog(travelcartActivity.this, myStartDateSetListener,
                        myYear, myMonth, myDay);
                dlgDate.show();
            }
        });

        travelenddate = view.findViewById(R.id.travelenddate);
        travelenddate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myYear = c.get(Calendar.YEAR);
                myMonth = c.get(Calendar.MONTH);
                myDay = c.get(Calendar.DAY_OF_MONTH);

                Dialog dlgDate = new DatePickerDialog(travelcartActivity.this, myEndDateSetListener,
                        myYear, myMonth, myDay);
                dlgDate.show();
            }
        });


        //timepicker
        travelstarttime = view.findViewById(R.id.travelstarttime);
        travelstarttime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myHour = c.get(Calendar.HOUR_OF_DAY);
                myMinute = c.get(Calendar.MINUTE);
                Dialog dlgTime = new TimePickerDialog(travelcartActivity.this, myStartTimeSetListener,
                        myHour, myMinute, false);
                dlgTime.show();
            }
        });


        travelendtime = view.findViewById(R.id.travelendtime);
        travelendtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myHour = c.get(Calendar.HOUR_OF_DAY);
                myMinute = c.get(Calendar.MINUTE);
                Dialog dlgTime = new TimePickerDialog(travelcartActivity.this, myEndTimeSetListener,
                        myHour, myMinute, false);
                dlgTime.show();
            }
        });


    }
    private void init(){
        nav = findViewById(R.id.navigationView);
    }

    //timepicker
    private DatePickerDialog.OnDateSetListener myStartDateSetListener
            = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            travelstartdate.setText(String.valueOf(year)+'년'+ String.valueOf(monthOfYear + 1)+'월'+String.valueOf(dayOfMonth)+'일');
            String date = String.valueOf(year)+'년'+ String.valueOf(monthOfYear + 1)+'월'+String.valueOf(dayOfMonth)+'일';
            Toast.makeText(travelcartActivity.this, date, Toast.LENGTH_LONG).show();
        }
    };

    private DatePickerDialog.OnDateSetListener myEndDateSetListener
            = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            travelenddate.setText(String.valueOf(year)+'년'+ String.valueOf(monthOfYear + 1)+'월'+String.valueOf(dayOfMonth)+'일');
            String date = String.valueOf(year)+'년'+ String.valueOf(monthOfYear + 1)+'월'+String.valueOf(dayOfMonth)+'일';
            Toast.makeText(travelcartActivity.this, date, Toast.LENGTH_LONG).show();
        }
    };

    //timepicker
    private TimePickerDialog.OnTimeSetListener myStartTimeSetListener
            = new TimePickerDialog.OnTimeSetListener() {

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            travelstarttime.setText(String.valueOf(hourOfDay)+ "시" + String.valueOf(minute) + "분");
            String time = String.valueOf(hourOfDay)+ "시" + String.valueOf(minute) + "분에 출발합니다!";
            Toast.makeText(travelcartActivity.this, time, Toast.LENGTH_LONG).show();
        }
    };

    private TimePickerDialog.OnTimeSetListener myEndTimeSetListener
            = new TimePickerDialog.OnTimeSetListener() {

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            travelendtime.setText(String.valueOf(hourOfDay)+ "시" + String.valueOf(minute) + "분");
            String time =String.valueOf(hourOfDay)+ "시" + String.valueOf(minute) + "분에 도착합니다!";
            Toast.makeText(travelcartActivity.this, time, Toast.LENGTH_LONG).show();
        }
    };
}