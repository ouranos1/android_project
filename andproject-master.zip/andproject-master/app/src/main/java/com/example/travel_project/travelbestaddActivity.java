package com.example.travel_project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class travelbestaddActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.travelbestadd);

        Button mapbutton = (Button) findViewById(R.id.ViewMap);

        mapbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("맵들어가기");
                Intent mapview = new Intent(getApplicationContext(), mapActivity.class);
                startActivity(mapview);
            }
        });

    }
    public void clicktraveladdcancel(View view) {
        Intent intent = new Intent(this,travelbestActivity.class);
        startActivity(intent);
    }
}