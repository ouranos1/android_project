package com.example.travel_project;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.navigation.NavigationView;
import java.util.Calendar;
import android.widget.TextView;

public class travelplanActivity extends Activity {

    private int myYear, myMonth, myDay, myHour, myMinute;

    Button travelplan;
    Button travelplanremove;
    Button btnOK;
    Button btnClose;
    Button travelstartdate;
    Button travelenddate;

    private static final String TAG = "travelplanActivity";

    private Context mContext = travelplanActivity.this;
    private NavigationView nav;

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "onNewIntent: 호출");
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.travelplan);




        init();
        NavigationViewHelper.enableNavigation(mContext,nav);


        final DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);

        findViewById(R.id.imageMenu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // start에 지정된 Drawer 열기
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        NavigationView navigationView = findViewById(R.id.navigationView);
        navigationView.setItemIconTintList(null);

        //여행 계획 삭제
        travelplanremove = findViewById(R.id.travelplanremove);
        RadioGroup  rg = (RadioGroup) findViewById(R.id.trabelplanRadiogroup);

        travelplanremove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton rd = (RadioButton) findViewById(rg.getCheckedRadioButtonId());
                rd.setVisibility(View.GONE);
                String rdtext = rd.getText().toString();
                Toast.makeText(getApplicationContext(), "'"+ rdtext + "' 여행 계획을 삭제했습니다.", Toast.LENGTH_LONG).show();
            }
        });


        //bottomsheet 구현 https://jwsoft91.tistory.com/45 I love tistory.
        travelplan = findViewById(R.id.travelplan);

        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.bottomsheet_travelplan, null, false);
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(view);

        travelplan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.show();
            }
        });

        btnOK = view.findViewById(R.id.btnOK);
        btnClose = view.findViewById(R.id.btnClose);
        travelstartdate = view.findViewById(R.id.travelstartdate);
        travelenddate = view.findViewById(R.id.travelenddate);
        EditText travelPlanName = (EditText)view.findViewById(R.id.travelPlanName);

        //여행 계획 추가
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (travelPlanName.getText().toString().length() == 0) {
                    Toast.makeText(getApplicationContext(), "여행 계획 이름을 입력하세요.", Toast.LENGTH_LONG).show();
                } else if (travelstartdate.getText().toString().length() == 8 || travelenddate.getText().toString().length() == 8) {
                    Toast.makeText(getApplicationContext(), "여행 날짜를 설정하세요.", Toast.LENGTH_LONG).show();
                } else {

                    RadioButton b_place = new RadioButton(travelplanActivity.this);

                    b_place.setText(travelPlanName.getText().toString());
                    b_place.setWidth(230);
                    b_place.setHeight(90);
                    b_place.setTextSize(16);
                    b_place.setTextSize(15);
                    //id 생성 어케 해
                    b_place.setId(View.generateViewId());
                    rg.addView(b_place);


                    Toast.makeText(getApplicationContext(), "추가", Toast.LENGTH_SHORT).show();
                    bottomSheetDialog.dismiss();
                }
            }
        });


        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "취소", Toast.LENGTH_SHORT).show();
                bottomSheetDialog.dismiss();
            }
        });


        //datepicker
        final Calendar c = Calendar.getInstance();

        travelstartdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myYear = c.get(Calendar.YEAR);
                myMonth = c.get(Calendar.MONTH);
                myDay = c.get(Calendar.DAY_OF_MONTH);

                Dialog dlgDate = new DatePickerDialog(travelplanActivity.this, myStartDateSetListener,
                        myYear, myMonth, myDay);
                dlgDate.show();
            }
        });

        travelenddate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myYear = c.get(Calendar.YEAR);
                myMonth = c.get(Calendar.MONTH);
                myDay = c.get(Calendar.DAY_OF_MONTH);

                Dialog dlgDate = new DatePickerDialog(travelplanActivity.this, myEndDateSetListener,
                        myYear, myMonth, myDay);
                dlgDate.show();
            }
        });

    }
    private void init(){
        nav = findViewById(R.id.navigationView);
    }

    //datepicker
    private DatePickerDialog.OnDateSetListener myStartDateSetListener
            = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            travelstartdate.setText(String.valueOf(year)+'년'+ String.valueOf(monthOfYear + 1)+'월'+String.valueOf(dayOfMonth)+'일');
            String date = String.valueOf(year)+'년'+ String.valueOf(monthOfYear + 1)+'월'+String.valueOf(dayOfMonth)+'일';
            Toast.makeText(travelplanActivity.this, date, Toast.LENGTH_LONG).show();
        }
    };

    private DatePickerDialog.OnDateSetListener myEndDateSetListener
            = new DatePickerDialog.OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            travelenddate.setText(String.valueOf(year)+'년'+ String.valueOf(monthOfYear + 1)+'월'+String.valueOf(dayOfMonth)+'일');
            String date = String.valueOf(year)+'년'+ String.valueOf(monthOfYear + 1)+'월'+String.valueOf(dayOfMonth)+'일';
            Toast.makeText(travelplanActivity.this, date, Toast.LENGTH_LONG).show();
        }
    };
}